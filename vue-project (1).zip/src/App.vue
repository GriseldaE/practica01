<script>
  export default {
  name: "BaseBlock",
  data() {
    return {
      array: ["Rápido, Vite-powered build toolchain.", "Más ergonómico Composición API sintaxis a través de <script setup>", "Soporte mejorado de TypeScript IDE para Componentes de Archivo Único a través de Volar.", "Comprobación de tipo de línea de comandos para SFC a través de vue-tsc.","Gestión de estados más sencilla a través de Pinia.","Nueva extensión de herramientas de desarrollo con soporte simultáneo para Vue 2 / Vue 3 y un sistema de plugins que permite a las bibliotecas de la comunidad conectarse a los paneles de herramientas de desarrollo."],
    };
  },
};
</script>

<script setup>
import {ref} from "vue";

 const activate = true;

 const Mododia = "background:white, color:black";
 const Modonoche = "background:black; color:white;";
 const modo = Mododia;
  </script>

<template>
<body :style="Modonoche" >
  <h1>Vue 3</h1>
  
  <p>Vue es un framework de JavaScript para construir interfaces de usuario. Está diseñado para crear aplicaciones web interactivas y modernas con rapidez y facilidad. También se consolida como una de las herramientas más queridas por los ingenieros de software.</p>
  <p v-if="activate">Vue 3 es la última versión de este framework, prometiendo mejoras en rendimiento, sintaxis y capacidades sin precedentes. Las novedades incluyen optimización del código, mejoras en la sintaxis y el manejo de errores, así como nuevas características como Suspense y Composition API. Esta última nos permite escribir códigos más simples, limpios y reutilizables.</p>
  
  
  <h2>Características</h2>
  <div>
    <div v-for="item in array"> • {{ item }}</div>
  </div> 
  

  
  </body>
  </template>
